/************************************************************************/
/**   This program detects lines in given image and draws them on it   **/
/************************************************************************/

#include <stdio.h>
#include "opencv2/opencv.hpp"
#include "../include/Detection.h"

using namespace cv;
using namespace std;

int main(int argc, char** argv)
{
	const char* FileName = "court1.jpg";
	int Thickness = 9;
	double SlopeTolerance = 10;

	if (argc > 1) FileName = argv[1];
	if (argc > 2) Thickness = std::stoi(argv[2]);
	if (argc > 3) SlopeTolerance = std::stod(argv[3]);

	Mat Image = imread(FileName);
	if (!Image.data)
	{
		printf("Image cannot be opened.");
		system("pause");
		return -1;
	}


	vector<Vec2f> Lines = ::Lines(Image, Thickness, SlopeTolerance);

	for (vector<Vec2f>::iterator Selected = Lines.begin(); Selected != Lines.end(); Selected++)
	{
		float rho = (*Selected)[0], theta = (*Selected)[1];
		Point pt1, pt2;
		double a = cos(theta), b = sin(theta);
		double x0 = a * rho, y0 = b * rho;
		pt1.x = cvRound(x0 + 1000 * (-b));
		pt1.y = cvRound(y0 + 1000 * (a));
		pt2.x = cvRound(x0 - 1000 * (-b));
		pt2.y = cvRound(y0 - 1000 * (a));
		line(Image, pt1, pt2, Scalar(0, 0, 255), 3, LINE_AA);
	}

	imshow("Lines detected", Image);

	waitKey(0);
	return 0;
}
