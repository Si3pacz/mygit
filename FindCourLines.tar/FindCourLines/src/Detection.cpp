/************************************************/
/** This function detects lines in given image **/
/************************************************/

#include "../include/Detection.h"

using namespace cv;
using namespace std;

std::vector<cv::Vec2f> Lines(cv::Mat Image, int Thickness, double SlopeTolerance)
{
	// Converting to grayscale for processing.
	cvtColor(Image, Image, COLOR_BGR2GRAY);

	// Processing for line recognition - blurring out the noise and detecting edges.
	GaussianBlur(Image, Image, Size(Thickness, Thickness), 0);
	Canny(Image, Image, 15, 30, 3);

	vector<Vec2f> Lines;
	HoughLines(Image, Lines, 1, CV_PI / 180, 150, 0, 0);

	// Reducing the number of lines by merging similar ones by parameter averages.
	for (vector<Vec2f>::iterator Selected = Lines.begin(); Selected != Lines.end(); Selected++)
	{
		Vec2f Sum = *Selected;
		int MatchAmount = 1;

		for (vector<Vec2f>::iterator Candidate = ++vector<Vec2f>::iterator(Selected); Candidate != Lines.end();)
			if (abs((*Selected)[0] - (*Candidate)[0]) < Thickness && abs((*Selected)[1] - (*Candidate)[1]) < SlopeTolerance * CV_PI / 180)
			{
				Sum += *Candidate;
				MatchAmount++;
				Candidate = Lines.erase(Candidate);
			}
			else Candidate++;

		*Selected = Sum / MatchAmount;
	}

	return Lines;
}
