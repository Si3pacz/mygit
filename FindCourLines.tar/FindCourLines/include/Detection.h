#ifndef DETECTION_H_INCLUDED
#define DETECTION_H_INCLUDED

#include <vector>
#include "/opencv2/opencv.hpp"

/* Mathematical representations of straight lines with given Thickness in the image.
    In this demo:
        Thickness must be odd, to meet blur requirements.
        SlopeTolerance determines threshold for merging lines.
*/

std::vector<cv::Vec2f> Lines(cv::Mat Image, int Thickness = 9, double SlopeTolerance = 10);

#endif // DETECTION_H_INCLUDED
